<?php 

include "../../resources/config.php";

?>