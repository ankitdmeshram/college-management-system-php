<div class="gs-sidebar gs-col bg-dark" id="gs-sidebar">
                <h3 class="p-3">Admin</h3>
                <ul class="gs-scroll pt-2">
                    <a href="./">
                        <li><i class="fa fa-sign-in" aria-hidden="true"></i> Dashboard</li>
                    </a>
                    <a href="./students">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Students
                        </li>
                    </a>
                    <a href="./academics">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Academics
                        </li>
                    </a>
                    <a href="./library">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Library
                        </li>
                    </a>
                    <!-- <a href="./fees">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Fees
                        </li>
                    </a>
                    <a href="./examination">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Examination
                        </li>
                    </a> -->
                    <a href="./users">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Users
                        </li>
                    </a>
                   
                   
                </ul>
            </div>













