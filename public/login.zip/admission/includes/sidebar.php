<div class="gs-sidebar gs-col bg-dark" id="gs-sidebar">
                <h3 class="p-3">Admission</h3>
                <ul class="gs-scroll pt-2">
                    <a href="./">
                        <li><i class="fa fa-sign-in" aria-hidden="true"></i> Basic Information</li>
                    </a>
                    <a href="./program">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Programme
                        </li>
                    </a>
                    <a href="./personal-details">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Personal Details
                        </li>
                    </a>
                    <a href="./education-details">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Education Details
                        </li>
                    </a>
                    <a href="./upload-documents">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Upload Documents
                        </li>
                    </a>
                    <a href="./payments">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Payments
                        </li>
                    </a>
                    <a href="/blank">
                        <li>
                            <i class="fa fa-sign-in" aria-hidden="true"></i> Finish
                        </li>
                    </a>
                   
                </ul>
            </div>













